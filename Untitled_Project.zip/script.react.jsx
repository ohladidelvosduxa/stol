import React from 'react';

function App() {
  // Стили для контейнера (молочный фон)
  const containerStyle = {
    backgroundColor: '#F5F5DC', // Молочный цвет
    width: '100vw',
    height: '100vh',
    margin: 0,
    padding: 0,
    position: 'relative',
    overflow: 'hidden',
  };

  // Стили для стола
  const tableStyle = {
    position: 'absolute',
    width: '500px',
    height: '120px',
    backgroundColor: '#8B4513', // Коричневый стол
    bottom: '20%',
    left: '50%',
    transform: 'translateX(-50%)',
    borderRadius: '8px',
  };

  // Стили для человека (сидящего за столом)
  const personStyle = {
    position: 'absolute',
    width: '60px',
    height: '100px',
    backgroundColor: '#333',
    borderRadius: '10px',
    bottom: '32%',
    left: '50%',
    transform: 'translateX(-50%)',
    zIndex: 5,
  };

  // Голова человека
  const headStyle = {
    position: 'absolute',
    width: '40px',
    height: '40px',
    backgroundColor: '#FFCC99',
    borderRadius: '50%',
    top: '-30px',
    left: '10px',
  };

  // Руки человека
  const armLeftStyle = {
    position: 'absolute',
    width: '10px',
    height: '40px',
    backgroundColor: '#333',
    top: '20px',
    left: '-5px',
    transform: 'rotate(15deg)',
    borderRadius: '5px',
  };

  // Стили для стула
  const chairStyle = {
    position: 'absolute',
    width: '80px',
    height: '20px',
    backgroundColor: '#8B4513',
    bottom: '15%',
    left: '46%',
    transform: 'translateX(-50%)',
    borderRadius: '5px',
  };

  // Стили для рамки с фотографией
  const frameStyle = {
    position: 'absolute',
    width: '150px',
    height: '100px',
    border: '8px solid #5D4037', // Рамка
    bottom: '25%',
    left: '30%',
    backgroundColor: '#FFD700', // Желтый свет внутри
    borderRadius: '5px',
    boxShadow: '0 0 15px rgba(255, 215, 0, 0.7)', // Эффект свечения
    zIndex: 3,
  };

  // Стили для вазы
  const vaseStyle = {
    position: 'absolute',
    width: '40px',
    height: '60px',
    backgroundColor: '#4CAF50', // Зеленая ваза
    bottom: '25%',
    right: '30%',
    borderRadius: '40% 40% 20% 20%',
    zIndex: 3,
  };

  // Стили для цветов
  const flower1Style = {
    position: 'absolute',
    width: '20px',
    height: '20px',
    backgroundColor: '#FF69B4', // Розовый
    borderRadius: '50%',
    top: '-15px',
    left: '10px',
  };

  const flower2Style = {
    position: 'absolute',
    width: '20px',
    height: '20px',
    backgroundColor: '#FF0000', // Красный
    borderRadius: '50%',
    top: '-20px',
    left: '20px',
  };

  const flower3Style = {
    position: 'absolute',
    width: '20px',
    height: '20px',
    backgroundColor: '#0000FF', // Синий
    borderRadius: '50%',
    top: '-15px',
    left: '30px',
  };

  // Стили для друзей (5 наблюдающих)
  const friendBaseStyle = {
    position: 'absolute',
    width: '30px',
    height: '60px',
    backgroundColor: '#555',
    borderRadius: '8px',
    zIndex: 2,
  };

  const friendHeadBaseStyle = {
    position: 'absolute',
    width: '20px',
    height: '20px',
    backgroundColor: '#FFCC99',
    borderRadius: '50%',
    top: '-15px',
  };

  // Позиции для 5 друзей
  const friends = [
    { left: '20%', bottom: '25%' },
    { left: '30%', bottom: '22%' },
    { left: '40%', bottom: '20%' },
    { left: '60%', bottom: '20%' },
    { left: '70%', bottom: '22%' },
  ];

  // 6-й друг уходит с солнцем
  const friend6Style = {
    position: 'absolute',
    width: '30px',
    height: '60px',
    backgroundColor: '#555',
    borderRadius: '8px',
    left: '80%',
    bottom: '25%',
    zIndex: 2,
  };

  const friend6HeadStyle = {
    position: 'absolute',
    width: '20px',
    height: '20px',
    backgroundColor: '#FFCC99',
    borderRadius: '50%',
    top: '-15px',
    left: '5px',
  };

  // Солнце в руках 6-го друга
  const sunStyle = {
    position: 'absolute',
    width: '30px',
    height: '30px',
    backgroundColor: '#FFFF00',
    borderRadius: '50%',
    left: '40px',
    top: '10px',
    boxShadow: '0 0 15px #FFFF00',
  };

  // Лучи солнца
  const sunRayStyle = {
    position: 'absolute',
    width: '10px',
    height: '2px',
    backgroundColor: '#FFFF00',
    left: '35px',
    top: '25px',
    transform: 'rotate(45deg)',
  };

  return (
    <div style={containerStyle}>
      {/* Стол */}
      <div style={tableStyle}></div>
      
      {/* Стул */}
      <div style={chairStyle}></div>
      
      {/* Человек */}
      <div style={personStyle}>
        <div style={headStyle}></div>
        <div style={armLeftStyle}></div>
      </div>
      
      {/* Рамка с фотографией */}
      <div style={frameStyle}></div>
      
      {/* Ваза с цветами */}
      <div style={vaseStyle}>
        <div style={flower1Style}></div>
        <div style={flower2Style}></div>
        <div style={flower3Style}></div>
      </div>

      {/* 5 друзей наблюдают */}
      {friends.map((pos, index) => (
        <div key={index} style={{...friendBaseStyle, ...pos}}>
          <div style={{...friendHeadBaseStyle, left: '5px'}}></div>
        </div>
      ))}

      {/* 6-й друг уходит с солнцем */}
      <div style={friend6Style}>
        <div style={friend6HeadStyle}></div>
        <div style={sunStyle}>
          <div style={sunRayStyle}></div>
          <div style={{...sunRayStyle, transform: 'rotate(90deg)'}}></div>
          <div style={{...sunRayStyle, transform: 'rotate(135deg)'}}></div>
          <div style={{...sunRayStyle, transform: 'rotate(180deg)'}}></div>
          <div style={{...sunRayStyle, transform: 'rotate(225deg)'}}></div>
          <div style={{...sunRayStyle, transform: 'rotate(270deg)'}}></div>
          <div style={{...sunRayStyle, transform: 'rotate(315deg)'}}></div>
          <div style={{...sunRayStyle, transform: 'rotate(0deg)'}}></div>
        </div>
      </div>
    </div>
  );
}

export default App;